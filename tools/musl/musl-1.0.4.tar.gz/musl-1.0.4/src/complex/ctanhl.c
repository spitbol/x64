#include "libm.h"

//FIXME
long double complex ctanhl(long double complex z)
{
	return ctanh(z);
}
